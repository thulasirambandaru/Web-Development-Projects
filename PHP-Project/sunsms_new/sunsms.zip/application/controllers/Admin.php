<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->library('Datatables');
		$this->load->model("mwelcome");

		if($this->session->userdata('user_id') && $this->session->userdata('user_type_id')==2){}
		else{
			redirect(BASE_URL);
		}
	}

	function index()
	{
		$data['school'] = $this->mwelcome->getSchool(array('id_school' => $this->session->userdata('school_id')));
		$data['state'] = $this->mwelcome->getState(array('country_id' => $data['school'][0]['country_id']));
		$data['city'] = $this->mwelcome->getCity(array('state_id' => $data['school'][0]['state_id']));
		$data['county'] = $this->mwelcome->getCountry();

		$data['header']="header";
		$data['left_menu']="left_menu";
		//$data['middle_content']='admin/dashboard';
		$data['middle_content']='admin/school_setup';
		$data['footer']='footer';
		$data['menu'] = 'school-setup';
		$this->load->view('landing',$data);
	}

	function updateSchool()
	{
		if(isset($_FILES['school_logo']['name']) && $_FILES['school_logo']['name']!=''){
			$file_type = check_file_type($_FILES['school_logo']['name'],'image');
			if($file_type) {
				$school_image = do_upload($_FILES['school_logo']['name'], $_FILES['school_logo']['tmp_name'], $this->session->userdata('school_id'));
				$_POST['school_logo'] = $school_image;
			}
		}
		else{
			$_POST['school_logo'] = $_POST['prev_school_logo'];
		}
		if(isset($_FILES['fav_icon']['name']) && $_FILES['fav_icon']['name']!=''){
			$file_type = check_file_type($_FILES['fav_icon']['name'],'image');
			if($file_type) {
				$school_image = do_upload($_FILES['fav_icon']['name'], $_FILES['fav_icon']['tmp_name'], $this->session->userdata('school_id'));
				$_POST['fav_icon'] = $school_image;
			}
		}
		else{
			$_POST['fav_icon'] = $_POST['prev_fav_icon'];
		}

		$this->mwelcome->updateSchool(array(
			'id_school' => $this->session->userdata('school_id'),
			'school_name' => $_POST['school_name'],
			'registration_id' => $_POST['registration_id'],
			'founded_on' => date('Y-m-d',strtotime($_POST['founded_on'])),
			'curriculam' => $_POST['curriculam'],
			'school_logo' => $_POST['school_logo'],
			'country_id' => $_POST['country_id'],
			'state_id' => $_POST['state_id'],
			'city_id' => $_POST['city_id'],
			'address' => $_POST['address'],
			'pincode' => $_POST['pincode'],
			'phone' => $_POST['phone'],
			'alternative_phone' => $_POST['alternative_phone'],
			'email' => $_POST['email'],
			'fax' => $_POST['fax'],
			'principle_name' => $_POST['principle_name'],
			'principle_email' => $_POST['principle_email'],
			'principle_phone' => $_POST['principle_phone'],
			'principle_mobile' => $_POST['principle_mobile'],
		));


		redirect(BASE_URL.'index.php/admin/');
	}

	function academicYear()
	{
		$data['header']="header";
		$data['left_menu']="left_menu";
		$data['middle_content']='admin/academic_year';
		$data['footer']='footer';
		$data['menu'] = 'school-setup';
		$this->load->view('landing',$data);
	}

	function getAcademicYearDataTable()
	{
		$results = json_decode($this->mwelcome->getAcademicYearDataTable($_POST));

		for($s=0;$s<count($results->data);$s++)
		{
			$results->data[$s][4] = encode($results->data[$s][4]);
		}
		echo json_encode($results);
	}

	function addAcademicYear($academic_year=0)
	{
		if($academic_year===0){}
		else{
			$data['academic_year'] = $this->mwelcome->getAcademicYear(array('id_academic_year' => decode($academic_year)));
		}
		$data['header']="header";
		$data['left_menu']="left_menu";
		$data['middle_content']='admin/add_academic_year';
		$data['footer']='footer';
		$data['menu'] = 'school-setup';
		$this->load->view('landing',$data);
	}

	function createAcademicYear()
	{
		if(isset($_POST))
		{
			if(!isset($_POST['status'])){ $status=0; }
			else{ $status = $_POST['status']; }

			if(!$_POST['id_academic_year'])
			{
				$this->mwelcome->addAcademicYear(array(
					'school_id' => $this->session->userdata('school_id'),
					'name' => $_POST['name'],
					'start_date' => date('Y-m-d',strtotime($_POST['start_date'])),
					'end_date' => date('Y-m-d',strtotime($_POST['end_date'])),
					'description' => $_POST['description'],
					'status' => $status
				));
			}
			else
			{
				$this->mwelcome->updateAcademicYear(array(
					'id_academic_year' => decode($_POST['id_academic_year']),
					'name' => $_POST['name'],
					'start_date' => date('Y-m-d',strtotime($_POST['start_date'])),
					'end_date' => date('Y-m-d',strtotime($_POST['end_date'])),
					'description' => $_POST['description'],
					'status' => $status
				));
			}

			redirect(BASE_URL.'index.php/admin/academicYear');
		}
	}

	function deleteAcademicYear($id)
	{
		$this->mwelcome->deleteAcademicYear(decode($id));
		echo json_encode(array('response' => 1,'data' =>''));
	}

	function board()
	{
		$data['header']="header";
		$data['left_menu']="left_menu";
		$data['middle_content']='admin/board';
		$data['footer']='footer';
		$data['menu'] = 'board';
		$this->load->view('landing',$data);
	}

	function getBoardDataTable()
	{
		$results = json_decode($this->mwelcome->getBoardDataTable($_POST));

		for($s=0;$s<count($results->data);$s++)
		{
			$results->data[$s][2] = encode($results->data[$s][2]);
		}
		echo json_encode($results);
	}

	function addBoard($board_id=0)
	{
		if($board_id===0){}
		else{
			$data['board'] = $this->mwelcome->getBoard(array('id_board' => decode($board_id)));
		}

		$data['header']="header";
		$data['left_menu']="left_menu";
		$data['middle_content']='admin/add_board';
		$data['footer']='footer';
		$data['menu'] = 'board';
		$this->load->view('landing',$data);
	}

	function createBoard()
	{
		//echo "<pre>";print_r($_POST); exit;
		if(isset($_POST))
		{
			if(!isset($_POST['status'])){ $status=0; }
			else{ $status = $_POST['status']; }

			if(!$_POST['id_board'])
			{
				$this->mwelcome->addBoard(array(
					'school_id' => $this->session->userdata('school_id'),
					'board_name' => $_POST['name'],
					'board_description' => $_POST['description'],
					'status' => $status
				));
			}
			else
			{
				$this->mwelcome->updateBoard(array(
					'id_board' => decode($_POST['id_board']),
					'board_name' => $_POST['name'],
					'board_description' => $_POST['description'],
					'status' => $status
				));
			}

			redirect(BASE_URL.'index.php/admin/board');
		}
	}

	function deleteBoard($id)
	{
		$this->mwelcome->deleteBoard(decode($id));
		echo json_encode(array('response' => 1,'data' =>''));
	}

	function course()
	{
		$data['header']="header";
		$data['left_menu']="left_menu";
		$data['middle_content']='admin/class';
		$data['footer']='footer';
		$data['menu'] = 'course';
		$this->load->view('landing',$data);
	}

	function getCourseDataTable()
	{
		$results = json_decode($this->mwelcome->getCourseDataTable($_POST));

		for($s=0;$s<count($results->data);$s++)
		{
			$results->data[$s][4] = encode($results->data[$s][4]);
		}
		echo json_encode($results);
	}

	function addCourse($board_id=0)
	{
		if($board_id===0){}
		else{
			$data['course'] = $this->mwelcome->getCourse(array('id_course' => decode($board_id)));
		}
		$data['board'] = $this->mwelcome->getBoard(array('school_id' => $this->session->userdata('school_id'),'status' => 1));
		$data['header']="header";
		$data['left_menu']="left_menu";
		$data['middle_content']='admin/add_class';
		$data['footer']='footer';
		$data['menu'] = 'course';
		$this->load->view('landing',$data);
	}

	function createCourse()
	{
		//echo "<pre>";print_r($_POST); exit;
		if(isset($_POST))
		{
			if(!isset($_POST['status'])){ $status=0; }
			else{ $status = $_POST['status']; }

			if(!$_POST['id_course'])
			{
				$this->mwelcome->addCourse(array(
					'school_id' => $this->session->userdata('school_id'),
					'board_id' => $_POST['board_id'],
					'course_name' => $_POST['name'],
					'code' => $_POST['code'],
					'status' => $status
				));
			}
			else
			{
				$this->mwelcome->updateCourse(array(
					'id_course' => decode($_POST['id_course']),
					'board_id' => $_POST['board_id'],
					'course_name' => $_POST['name'],
					'code' => $_POST['code'],
					'status' => $status
				));
			}

			redirect(BASE_URL.'index.php/admin/course');
		}
	}

	function deleteCourse($id)
	{
		$this->mwelcome->deleteCourse(decode($id));
		echo json_encode(array('response' => 1,'data' =>''));
	}

	function subject()
	{
		$data['header']="header";
		$data['left_menu']="left_menu";
		$data['middle_content']='admin/subject';
		$data['footer']='footer';
		$data['menu'] = 'subject';
		$this->load->view('landing',$data);
	}

	function getSubjectDataTable()
	{
		$results = json_decode($this->mwelcome->getSubjectDataTable($_POST));

		for($s=0;$s<count($results->data);$s++)
		{
			$results->data[$s][4] = encode($results->data[$s][4]);
		}
		echo json_encode($results);
	}

	function addSubject($subject_id=0)
	{
		if($subject_id===0){}
		else{
			$data['subject'] = $this->mwelcome->getSubject(array('id_subject' => decode($subject_id)));
		}
		//echo "<pre>";print_r($data['subject']); exit;
		$data['course'] = $this->mwelcome->getCourse(array('school_id' => $this->session->userdata('school_id'),'status' => 1));
		$data['header']="header";
		$data['left_menu']="left_menu";
		$data['middle_content']='admin/add_subject';
		$data['footer']='footer';
		$data['menu'] = 'subject';
		$this->load->view('landing',$data);
	}

	function createSubject()
	{
		if(isset($_POST))
		{
			if(!isset($_POST['status'])){ $status=0; }
			else{ $status = $_POST['status']; }

			if(!$_POST['id_subject'])
			{
				$this->mwelcome->addSubject(array(
					'course_id' => $_POST['course_id'],
					'subject_name' => $_POST['name'],
					'subject_code' => $_POST['code'],
					'status' => $status
				));
			}
			else
			{
				$this->mwelcome->updateSubject(array(
					'id_subject' => decode($_POST['id_subject']),
					'course_id' => $_POST['course_id'],
					'subject_name' => $_POST['name'],
					'subject_code' => $_POST['code'],
					'status' => $status
				));
			}

			redirect(BASE_URL.'index.php/admin/subject');
		}
	}

	function deleteSubject($id)
	{
		$this->mwelcome->deleteSubject(decode($id));
		echo json_encode(array('response' => 1,'data' =>''));
	}


}
