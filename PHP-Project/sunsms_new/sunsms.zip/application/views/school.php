



    <section class="col-lg-10 right-section">

        <ul class="breadcrumb border-btm">
            <li>
                <a href="#">Home</a>

            </li>

            <li class="active">
                Dashboard
            </li>
        </ul>

        <table id="table" class="table table-bordered table-hover">
            <thead>
            <tr>
                <th>School Name</th>
                <th>User Name</th>
                <th>User Email</th>
                <th>city</th>
                <th>State</th>
                <th>Created date</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>



            </tbody>

        </table>

    </section>





<script type="text/javascript">
        $(function () {

            getCustomerDataTable();


        });
</script>