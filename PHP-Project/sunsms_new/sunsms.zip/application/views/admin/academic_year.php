



    <section class="col-lg-10 right-section">

        <ul class="breadcrumb border-btm">
            <li class="">
                <a href="<?=BASE_URL?>index.php/admin/index"> Dashboard </a>
            </li>

            <li class="active">
                Academic year
            </li>
        </ul>

        <table id="table" class="table table-bordered table-hover">
            <thead>
            <tr>
                <th>Name</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>



            </tbody>

        </table>

    </section>





<script type="text/javascript">
        $(function () {

            getAcademicYearDataTable();


        });
</script>