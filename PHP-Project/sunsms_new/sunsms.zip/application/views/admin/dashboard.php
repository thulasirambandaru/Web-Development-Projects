



<section class="col-lg-10 right-section">

    <ul class="breadcrumb border-btm">
        <li>
            <a href="#">Home</a>

        </li>
        <li>
            <a href="#">Metro Lab</a>

        </li>
        <li class="active">
            Dashboard
        </li>
    </ul>


    <div class="">
        <a href="#" class="quick-btn">
            <i class="fa fa-user fa-2x"></i>
            <span>Admission</span>

        </a>
        <a href="#" class="quick-btn">
            <i class="fa fa-user fa-2x"></i>
            <span>Student</span>

        </a>
        <a href="#" class="quick-btn">
            <i class="fa fa-user fa-2x"></i>
            <span>Employee</span>
        </a>
        <a href="#" class="quick-btn">
            <i class="fa fa-file-text-o fa-2x"></i>
            <span>Fees</span>

        </a>
        <a href="#" class="quick-btn">
            <i class="icon-list-alt fa-2x"></i>
            <span>Attendence</span>

        </a>
        <a href="#" class="quick-btn">
            <i class="fa fa-pencil-square-o fa-2x"></i>
            <span>Examination</span>

        </a>
        <a href="#" class="quick-btn">
            <i class="fa fa-calendar fa-2x"></i>
            <span>Timetable</span>

        </a>
        <a href="#" class="quick-btn">
            <i class="fa fa-clipboard fa-2x"></i>
            <span>Inventory</span>

        </a>
        <a href="#" class="quick-btn">
            <i class="fa fa-inr fa-2x"></i>
            <span>Payroll</span>

        </a>
        <a href="#" class="quick-btn">
            <i class="fa fa-bell-o fa-2x"></i>
            <span>Fess Alerts</span>

        </a>
    </div>


</section>



