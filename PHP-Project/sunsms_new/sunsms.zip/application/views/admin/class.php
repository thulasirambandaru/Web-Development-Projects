



    <section class="col-lg-10 right-section">

        <ul class="breadcrumb border-btm">
            <li class="">
                <a href="<?=BASE_URL?>index.php/admin/index"> Dashboard </a>
            </li>

            <li class="active">
                Class/Course
            </li>
        </ul>

        <table id="table" class="table table-bordered table-hover">
            <thead>
            <tr>
                <th>Board Name</th>
                <th>Course</th>
                <th>Code</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>



            </tbody>

        </table>

    </section>





<script type="text/javascript">
        $(function () {

            getCourseDataTable();


        });
</script>