<div id="left" class="">
    <!-- #menu -->
    <ul id="menu" class="bg-blue dker">
        <li class="nav-header">Quick Shortcuts</li>
        <li class="nav-divider"></li>
        <?php if(isset($menu) && $menu=='school'){ ?>
        <li class="active">
            <a href="<?=BASE_URL?>index.php/welcome/addSchool">
                <i class="fa fa-user"></i><span class="link-title"> Add School</span>
            </a>
        </li>
        <?php } else if(isset($menu) && $menu=='school-setup'){?>
            <li class="active">
                <a href="<?=BASE_URL?>index.php/admin/">
                    <i class="fa fa-user"></i><span class="link-title"> School setup</span>
                </a>
            </li>
            <li class="active">
                <a href="<?=BASE_URL?>index.php/admin/academicYear">
                    <i class="fa fa-user"></i><span class="link-title"> Academic year</span>
                </a>
            </li>
            <li class="active">
                <a href="<?=BASE_URL?>index.php/admin/addAcademicYear">
                    <i class="fa fa-user"></i><span class="link-title"> Add academic year</span>
                </a>
            </li>

        <?php } if(isset($menu) && $menu=='board'){ ?>
            <li class="active">
                <a href="<?=BASE_URL?>index.php/admin/addBoard">
                    <i class="fa fa-user"></i><span class="link-title"> Add board</span>
                </a>
            </li>
        <?php } else if(isset($menu) && $menu=='course'){ ?>
            <li class="active">
                <a href="<?=BASE_URL?>index.php/admin/addCourse">
                    <i class="fa fa-user"></i><span class="link-title"> Add Course</span>
                </a>
            </li>
        <?php } else if(isset($menu) && $menu=='subject'){ ?>
            <li class="active">
                <a href="<?=BASE_URL?>index.php/admin/addSubject">
                    <i class="fa fa-user"></i><span class="link-title"> Add Subject</span>
                </a>
            </li>
        <?php } ?>

    </ul><!-- /#menu -->
</div>