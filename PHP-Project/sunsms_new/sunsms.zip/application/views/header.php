<?php
header("cache-Control: no-store, no-cache, must-revalidate");
header("cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");

if($this->session->userdata('user_id')){ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>School</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="layout" content="main"/>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css">


    <link href="<?=BASE_URL?>css/font-awesome.css" rel="stylesheet" type="text/css">
    <link href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">

    <link href="<?=BASE_URL?>css/customize-template.css" type="text/css" media="screen, projection" rel="stylesheet" />
    <link href="<?=BASE_URL?>css/style-default.css" rel="stylesheet" id="style_color" />
    <!--<link href="<?/*=BASE_URL*/?>css/datepicker.css" rel="stylesheet" id="style_color" />-->


    <script>
        var BASE_URL = '<?=BASE_URL?>';
    </script>

    <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>-->
    <!--<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>-->
    <!--<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>-->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="//code.jquery.com/jquery-1.10.2.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>


</head>
<body>
<div class="main-wrapper container">
    <div class="navbar">

        <div class="navbar-inner">
            <a class="logo" href="#"><img src="<?=BASE_URL?>images/logo.png"/></a>
            <div class="top-container">
                <button class="btn btn-navbar" data-toggle="collapse" data-target="#app-nav-top-bar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <div id="app-nav-top-bar" class="nav-collapse">

                    <ul class="nav pull-right">
                        <li>
                            <a href="<?=BASE_URL?>index.php/welcome/logout">Logout</a>
                        </li>

                    </ul>


                </div>
            </div>
        </div>
    </div>
    <?php $this->load->view('header_menu'); ?>
    <div id="body-content">
<?php } else { ?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=1,initial-scale=1,user-scalable=1" />
    <title>School</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:100italic,100,300italic,300,400italic,400,700italic,700,900italic,900" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css">

    <link href="<?=BASE_URL?>css/customize-template.css" type="text/css" media="screen, projection" rel="stylesheet" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <script type="text/javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <!--[if lt IE 9]>

    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<?php } ?>
