<div class="body-nav body-nav-horizontal">
    <button class="nav-toggle">
        <b class="mobile-menu-txt">Menu</b>
        <div class="icon-menu"> <span class="line line-1"></span> <span class="line line-2"></span> <span class="line line-3"></span> </div>
    </button>
    <div class="main-top-nav">
        <ul  class="nav-menu menu">
            <?php if($this->session->userdata('user_type_id')==1){ ?>
            <li class="menu-item active">
                <a href="<?=BASE_URL?>" class="menu-link">
                    <i class="icon-dashboard icon-large"></i> Dashboard
                </a>
            </li>
            <?php } if($this->session->userdata('user_type_id')==2){ ?>
                <li class="menu-item <?php if(isset($menu) && $menu=='school-setup'){ echo 'active'; } ?>">
                    <a href="<?=BASE_URL?>index.php/admin/" class="menu-link">
                        <i class="icon-dashboard icon-large"></i> Dashboard
                    </a>
                </li>
                <li class="menu-item <?php if(isset($menu) && $menu=='board'){ echo 'active'; } ?>">
                    <a href="<?=BASE_URL?>index.php/admin/board" class="menu-link">
                        <i class="fa-clipboard icon-large"></i> Board
                    </a>
                </li>
                <li class="menu-item <?php if(isset($menu) && $menu=='course'){ echo 'active'; } ?>">
                    <a href="<?=BASE_URL?>index.php/admin/course" class="menu-link">
                        <i class="icon-dashboard icon-large"></i> Course/Class
                    </a>
                </li>
                <li class="menu-item <?php if(isset($menu) && $menu=='subject'){ echo 'active'; } ?>">
                    <a href="<?=BASE_URL?>index.php/admin/subject" class="menu-link">
                        <i class="icon-dashboard icon-large"></i> Subject
                    </a>
                </li>

            <?php } ?>
        </ul>
    </div>
</div>