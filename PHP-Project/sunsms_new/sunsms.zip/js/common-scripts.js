var Script = function () {

			   


// theme switcher

    /*var scrollHeight = '60px';
    jQuery('#theme-change').click(function () {
        if ($(this).attr("opened") && !$(this).attr("opening") && !$(this).attr("closing")) {
            $(this).removeAttr("opened");
            $(this).attr("closing", "1");

            $("#theme-change").css("overflow", "hidden").animate({
                width: '20px',
                height: '30px',
                'padding-top': '3px'
            }, {
                complete: function () {
                    $(this).removeAttr("closing");
                    $("#theme-change .settings").hide();
                }
            });
        } else if (!$(this).attr("closing") && !$(this).attr("opening")) {
            $(this).attr("opening", "1");
            $("#theme-change").css("overflow", "visible").animate({
                width: '226px',
                height: scrollHeight,
                'padding-top': '3px'
            }, {
                complete: function () {
                    $(this).removeAttr("opening");
                    $(this).attr("opened", 1);
                }
            });
            $("#theme-change .settings").show();
        }
    });

    jQuery('#theme-change .colors span').click(function () {
        var color = $(this).attr("data-style");
        setColor(color);
    });

    jQuery('#theme-change .layout input').change(function () {
        setLayout();
    });

    var setColor = function (color) {
        $('#style_color').attr("href", "css/style-" + color + ".css");
    }*/

}();


function getCustomerDataTable()
{
    $('#table').dataTable({
        "processing": true,
        "bProcessing": true,
        "serverSide": true,
        "bPaginate":true,
        "aaSorting": [],
        "ajax": {
            "url": BASE_URL+'index.php/welcome/getCustomerDataTable',
            "type": "POST",
            "data": function ( d ) {
                d.acolumns="id_school";
                d.my_order = "id_school";
                d.sort="desc";
            }
        },
        "aoColumnDefs": [
            {
                "aTargets": [6],
                "mData": null,
                "mRender": function (data, type, full) {

                    return '<div class="mod-more tooltipsample actions">'+
                        '<a id="edit" title="edit" class="edit" href="'+BASE_URL+'index.php/welcome/addSchool/'+full[6]+'"><span class="circle"><i class="fa fa-pencil"></i></span></a></a>' +
                        '</div>';
                }
            }
        ]
    });
}

function getState(country_id)
{
    var html = '<option value="0">Select State</option>';
    if(country_id==0){
        $('#state_id').html(html);
    }
    $.ajax({
        async: true,
        type: 'POST',
        url: BASE_URL+'index.php/welcome/getState/?country_id='+country_id,
        data: {},
        dataType: 'json',
        success:function(res){
            if(res.response==1){
                var data = res.data;
                for(var s=0;s<data.length;s++){
                    html+='<option value="'+data[s].id_state+'">'+data[s].state+'</option>';
                }
                $('#state_id').html(html);
            }
        }
    });
}

function getCity(state_id)
{
    var html = '<option value="0">Select City</option>';
    if(country_id==0){
        $('#city_id').html(html);
    }
    $.ajax({
        async: true,
        type: 'POST',
        url: BASE_URL+'index.php/welcome/getCity/?state_id='+state_id,
        data: {},
        dataType: 'json',
        success:function(res){
            if(res.response==1){
                var data = res.data;
                for(var s=0;s<data.length;s++){
                    html+='<option value="'+data[s].id_city+'">'+data[s].city+'</option>';
                }
                $('#city_id').html(html);
            }
        }
    });
}

function getAcademicYearDataTable()
{
    $('#table').dataTable({
        "processing": true,
        "bProcessing": true,
        "serverSide": true,
        "bPaginate":true,
        "aaSorting": [],
        "ajax": {
            "url": BASE_URL+'index.php/admin/getAcademicYearDataTable',
            "type": "POST",
            "data": function ( d ) {
                d.acolumns="id_academic_year";
                d.my_order = "id_academic_year";
                d.sort="desc";
            }
        },
        "aoColumnDefs": [
            {
                "aTargets": [3],
                "mData": null,
                "mRender": function (data, type, full) {

                    if(full[3]==0){ return "Inactive"; }
                    else { return "Active"; }
                }
            },
            {
                "aTargets": [4],
                "mData": null,
                "mRender": function (data, type, full) {

                    return '<div class="mod-more tooltipsample actions">'+
                        '<a id="edit" title="edit" class="edit" href="'+BASE_URL+'index.php/admin/addAcademicYear/'+full[4]+'"><span class="circle"><i class="fa fa-pencil"></i></span></a></a>' +
                        '<a id="edit" title="edit" class="edit" onclick="deleteAcademicYear(\''+full[4]+'\')" ><span class="circle"><i class="fa fa-trash"></i></span></a></a>' +
                        '</div>';
                }
            }
        ]
    });
}

function deleteAcademicYear(id)
{
    $.ajax({
        async: true,
        type: 'POST',
        url: BASE_URL+'index.php/admin/deleteAcademicYear/'+id,
        data: {},
        dataType: 'json',
        success:function(res){
            if(res.response==1){
                location.reload();
            }
        }
    });
}

function getBoardDataTable()
{
    $('#table').dataTable({
        "processing": true,
        "bProcessing": true,
        "serverSide": true,
        "bPaginate":true,
        "aaSorting": [],
        "ajax": {
            "url": BASE_URL+'index.php/admin/getBoardDataTable',
            "type": "POST",
            "data": function ( d ) {
                d.acolumns="id_board";
                d.my_order = "id_board";
                d.sort="desc";
            }
        },
        "aoColumnDefs": [
            {
                "aTargets": [1],
                "mData": null,
                "mRender": function (data, type, full) {

                    if(full[1]==0){ return "Inactive"; }
                    else { return "Active"; }
                }
            },
            {
                "aTargets": [2],
                "mData": null,
                "mRender": function (data, type, full) {

                    return '<div class="mod-more tooltipsample actions">'+
                        '<a id="edit" title="edit" class="edit" href="'+BASE_URL+'index.php/admin/AddBoard/'+full[2]+'"><span class="circle"><i class="fa fa-pencil"></i></span></a></a>' +
                        /*'<a id="edit" title="edit" class="edit" onclick="deleteBoard(\''+full[2]+'\')" ><span class="circle"><i class="fa fa-trash"></i></span></a></a>' +*/
                        '</div>';
                }
            }
        ]
    });
}

function deleteBoard(id)
{
    $.ajax({
        async: true,
        type: 'POST',
        url: BASE_URL+'index.php/admin/deleteBoard/'+id,
        data: {},
        dataType: 'json',
        success:function(res){
            if(res.response==1){
                location.reload();
            }
        }
    });
}

function getCourseDataTable()
{
    $('#table').dataTable({
        "processing": true,
        "bProcessing": true,
        "serverSide": true,
        "bPaginate":true,
        "aaSorting": [],
        "ajax": {
            "url": BASE_URL+'index.php/admin/getCourseDataTable',
            "type": "POST",
            "data": function ( d ) {
                d.acolumns="id_course";
                d.my_order = "id_course";
                d.sort="desc";
            }
        },
        "aoColumnDefs": [
            {
                "aTargets": [3],
                "mData": null,
                "mRender": function (data, type, full) {

                    if(full[3]==0){ return "Inactive"; }
                    else { return "Active"; }
                }
            },
            {
                "aTargets": [4],
                "mData": null,
                "mRender": function (data, type, full) {

                    return '<div class="mod-more tooltipsample actions">'+
                        '<a id="edit" title="edit" class="edit" href="'+BASE_URL+'index.php/admin/addCourse/'+full[4]+'"><span class="circle"><i class="fa fa-pencil"></i></span></a></a>' +
                        /*'<a id="edit" title="edit" class="edit" onclick="deleteCourse(\''+full[4]+'\')" ><span class="circle"><i class="fa fa-trash"></i></span></a></a>' +*/
                        '</div>';
                }
            }
        ]
    });
}

function deleteCourse(id)
{
    $.ajax({
        async: true,
        type: 'POST',
        url: BASE_URL+'index.php/admin/deleteCourse/'+id,
        data: {},
        dataType: 'json',
        success:function(res){
            if(res.response==1){
                location.reload();
            }
        }
    });
}

function getSubjectDataTable()
{
    $('#table').dataTable({
        "processing": true,
        "bProcessing": true,
        "serverSide": true,
        "bPaginate":true,
        "aaSorting": [],
        "ajax": {
            "url": BASE_URL+'index.php/admin/getSubjectDataTable',
            "type": "POST",
            "data": function ( d ) {
                d.acolumns="id_subject";
                d.my_order = "id_subject";
                d.sort="desc";
            }
        },
        "aoColumnDefs": [
            {
                "aTargets": [3],
                "mData": null,
                "mRender": function (data, type, full) {

                    if(full[3]==0){ return "Inactive"; }
                    else { return "Active"; }
                }
            },
            {
                "aTargets": [4],
                "mData": null,
                "mRender": function (data, type, full) {

                    return '<div class="mod-more tooltipsample actions">'+
                        '<a id="edit" title="edit" class="edit" href="'+BASE_URL+'index.php/admin/addSubject/'+full[4]+'"><span class="circle"><i class="fa fa-pencil"></i></span></a></a>' +
                        '<a id="edit" title="edit" class="edit" onclick="deleteSubject(\''+full[4]+'\')" ><span class="circle"><i class="fa fa-trash"></i></span></a></a>' +
                        '</div>';
                }
            }
        ]
    });
}

function deleteSubject(id)
{
    $.ajax({
        async: true,
        type: 'POST',
        url: BASE_URL+'index.php/admin/deleteSubject/'+id,
        data: {},
        dataType: 'json',
        success:function(res){
            if(res.response==1){
                location.reload();
            }
        }
    });
}