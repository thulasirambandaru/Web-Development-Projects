<?php
ini_set('display_errors','on');
define('ENV','local');
switch(ENV){
    case'local':
        define('BASE_URL','http://localhost/sunsms/');
        define('DB_HOST','localhost');
        define('DB_NAME', 'sunsms');
        define('DB_USERNAME', 'root');
        define('DB_PASSWORD', '');
        define('PAGING_LIST', 12); 

        /*Email Config*/
        define('SMTP_EMAIL','app.mazic@gmail.com');
        define('SMTP_PASSWORD','app_mazic.');

        break;

    case 'Live':
        define('BASE_URL','');
        //define('BASE_URL','http://www.affordbuy.com/seller/');
        define('DB_HOST','localhost');
        define('DB_NAME', 'sunsmsor_school');
        define('DB_USERNAME', 'sunsmsor_user');
        define('DB_PASSWORD', 'Sunsms@2016');
        define('PAGING_LIST', 12);

        /*Email Config*/
        define('SMTP_EMAIL','app.mazic@gmail.com');
        define('SMTP_PASSWORD','app_mazic.');
        
}
?>